package com.gdsc.nougly

data class RegisterOutput(
    var user: UserInfo,
    var token: String,
)



