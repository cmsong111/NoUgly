package com.gdsc.nougly

//data class Info(
  //  var all : ArrayList<MainOutput>
//)

data class MainOutput(
    var fIDX : String,
    var name : String,
    var grade : String,
    var date : String,
    var weight : String,
    var field : String,
    var price : String,
    var image : String,
    var hitcount : String,
    var kind : String
)
