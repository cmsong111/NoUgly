package com.gdsc.nougly

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [MainFragment.newInstance] factory method to
 * create an instance of this fragment.
 */

class MainFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        //retrofit
        var retrofit = Retrofit.Builder()
            .baseUrl("https://cmsong111.pythonanywhere.com/") //해당 링크
            .addConverterFactory(GsonConverterFactory.create()) //Gson 사용 선언
            .build() //객체 생성

        //Django에 넣을 GET 발행 소스
        var MainService = retrofit.create(MainService::class.java)

        //통신 과정 소스 - 결과보여주기 위해 LoginOutput과 연결
        MainService.requestMain().enqueue(object : Callback<ArrayList<MainOutput>> {

            override fun onResponse(call: Call<ArrayList<MainOutput>>, response: Response<ArrayList<MainOutput>>) {
                //
                //통신이 성공했을 때 - 응답값을 따옴

                var Main = response.body()

                if(Main != null){
                    val result = Main?.get(0)?.fIDX + Main?.get(0)?.name + Main?.get(0)?.grade + Main?.get(0)?.weight + Main?.get(0)?.field + Main?.get(0)?.price + Main?.get(0)?.image + Main?.get(0)?.hitcount + Main?.get(0)?.kind + Main?.get(1)?.fIDX + Main?.get(1)?.name + Main?.get(1)?.grade + Main?.get(1)?.weight + Main?.get(1)?.field + Main?.get(1)?.price + Main?.get(1)?.image + Main?.get(1)?.hitcount + Main?.get(1)?.kind
                    val duration = Toast.LENGTH_LONG


                    val applicationContext = getActivity()?.getApplicationContext()
                    val toast = Toast.makeText(applicationContext, result, duration)
                    toast.show()

                    Log.d("retrofit", "res" + result)

                }else{
                    Log.d("Error Code Test", response.errorBody()?.string()!!)
                }
            }

            override fun onFailure(call: Call<ArrayList<MainOutput>>, t: Throwable) {

                //통신이 실패했을 때
                Log.d("Debug", t.message.toString())

                //var dialog = AlertDialog.Builder(this@FRAGMENT_MAIN)
                //dialog.setTitle("통신실패")
                //dialog.setMessage("통신에 실패를 하였습니다.")
                //dialog.show()

                call.cancel()
            }
        })

        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment MainFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            MainFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}